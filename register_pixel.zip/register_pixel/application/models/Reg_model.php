<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reg_model extends CI_Model {

	public function __construct()
	{
		parent:: __construct();
		$this->load->database();
	}

	public function submit()
	{
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required');
		$this->form_validation->set_rules('user_email', 'User Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('user_phone', 'User Phone number', 'trim|required');
		$this->form_validation->set_rules('user_pwd', 'User Password', 'trim|required');
		//$this->form_validation->set_rules('user_pic', 'User Picture', 'required');
		$this->form_validation->set_rules('user_gender', 'User Gender', 'required');

		if ($this->form_validation->run() == false) {
			
			$this->session->set_flashdata('posted', $_POST);
			$this->session->set_flashdata('error', validation_errors());
			redirect('register', 'refresh');
		}
		else{

			$user_id     			   = $this->input->post('user_id');
			$insert['rg_username']     = $this->input->post('user_name');
			$insert['rg_usermail']     = $this->input->post('user_email');
			$insert['rg_user_phone']   = $this->input->post('user_phone');
			$insert['rg_user_pwd']     = $this->input->post('user_pwd');
			$insert['rg_user_gender']  = $this->input->post('user_gender');


			$file_name = "";
			$image_url = "";
			if (isset($_FILES['user_pic']) && !empty($_FILES['user_pic']['name'])) {
				if($_FILES['user_pic']['name']){
					$fileExt = pathinfo($_FILES['user_pic']['name'], PATHINFO_EXTENSION);
					if ($fileExt == 'jpg' || $fileExt == 'jpeg' || $fileExt == 'png' || $fileExt == 'gif') {
						$folderPath = dirname($_SERVER['SCRIPT_FILENAME']. "uploads/");
						if (!is_dir($folderPath)) mkdir($folderPath, 0777, TRUE);
						$target_path = "uploads/";
						$file_name = round(microtime(true)).".".$fileExt;
						$target_path = $target_path.$file_name;
						if (move_uploaded_file($_FILES['user_pic']['tmp_name'], $target_path)) {
							$full_path = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['SCRIPT_NAME']).'uploads/'.$file_name;
						}
					}
				}
				

				$insert['rg_user_pic'] = "uploads/" . $file_name;
			}

			if ($user_id >0) {
				
				$this->db->where('user_id', $user_id);
				$this->db->update('user_details', $insert);
			 $this->session->set_flashdata('success', 'Data Updated successfully'); 

			 $data['login_check'] = $this->db->get_where('user_details')->result_array();
			 //print_r($data['login_check']); die;
			 $this->load->view('user_profile', $data);
			}
			else{
			 
			 $this->db->insert('user_details', $insert);
			 $this->session->set_flashdata('success', 'Data inserted successfully'); 

			redirect('login', 'refresh');
			}
			
		}
	}
}
