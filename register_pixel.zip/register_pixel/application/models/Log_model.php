<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Log_model extends CI_Model {

	public function __construct()
	{
		parent:: __construct();
		$this->load->database();
	}

	public function submit()
	{
		$this->form_validation->set_rules('user_email', 'User Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('user_pwd', 'User Password', 'trim|required');

		if ($this->form_validation->run() == false) {
			
			$this->session->set_flashdata('posted', $_POST);
			$this->session->set_flashdata('error', validation_errors());
			redirect('login', 'refresh');
		}
		else{

			$user_email   = $this->input->post('user_email');
			$user_pwd    = $this->input->post('user_pwd');

			 $data['login_check'] = $this->db->get_where('user_details', array('rg_usermail' => $user_email, 'rg_user_pwd' => $user_pwd))->result_array();
			 
			 if ($data['login_check']) {
			   
			   $this->session->set_userdata('admin_in', $data['login_check']);
			   $this->load->view('user_profile', $data);
			   
			 }
			 else
			 {
			 	$this->session->set_flashdata('error', 'Incorrect credentials');
			 	redirect('login', 'refresh');
			 }
			
		}
	}

}
