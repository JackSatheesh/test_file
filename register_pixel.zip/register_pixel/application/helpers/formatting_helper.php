<?php	
function flash_success()
{
	$ci = get_instance(); 
	echo '<div class="alert alert-theme bg-success alert-dismissible text-white text-center">'.$ci->session->flashdata('success').'<span class="close" data-dismiss="alert" style="cursor:pointer;">×</span></div>';
	//echo '<div class="alert alert-theme bg-success alert-dismissible" role="alert"><button class="close" type="button" data-dismiss="alert" aria-label="Close"><span class="fa fa-close alert-success" aria-hidden="true"></span></button><div class="icon"></div><div class="message">'.$ci->session->flashdata('success').'</div></div>';
}
function flash_error()
{
	$ci = get_instance(); 
	echo '<div class="alert alert-theme bg-danger alert-dismissible text-white">'.$ci->session->flashdata('error').'<span class="close" data-dismiss="alert" style="cursor:pointer;">×</span></div>';
	//echo '<div class="alert alert-theme bg-success alert-dismissible" role="alert"><button class="close" type="button" data-dismiss="alert" aria-label="Close"><span class="fa fa-close alert-success" aria-hidden="true"></span></button><div class="icon"></div><div class="message">'.$ci->session->flashdata('success').'</div></div>';
}
