<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('Reg_model', 'reg_model');
	}

	public function index()
	{
		$this->load->view('register');
	}
	public function submit_data()
	{
		
		$this->reg_model->submit();
	}
}
