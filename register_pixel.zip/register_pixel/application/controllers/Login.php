<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('Log_model', 'log_model');
	}

	public function index()
	{
		$this->load->view('login');
	}
	public function submit_data()
	{
		
		$this->log_model->submit();
	}
	public function edit_user_profile($id)
	{
		$data['edit_user'] = $this->db->get_where('user_details', array('user_id' => $id))->row_array();
		$this->load->view('edit_reg', $data);
	}
	public function logout(){
		$session_data = $this->session->userdata('admin_in');	
		$this->session->unset_userdata('admin_in', $session_data);
		$this->session->set_flashdata('success', 'Logout Successfully');
		redirect('login', 'refresh');
	}
}
