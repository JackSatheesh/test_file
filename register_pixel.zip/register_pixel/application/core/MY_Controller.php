<?php
class Common_Controller extends CI_Controller {
	public function __construct() {
        parent::__construct();
		$this->load->helper(array('formatting_helper')); 
		//date_default_timezone_set('Asia/Kolkata');
		//$this->load->model(array('Common_model'));
	}

}