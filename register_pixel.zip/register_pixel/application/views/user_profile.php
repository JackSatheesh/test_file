<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>User Profile</title>
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>

<div id="container">
	<?php if($this->session->flashdata('error')) flash_error(); if($this->session->flashdata('success')) flash_success(); ?>
	<table class="table table-striped">
		<thead>
			<th>S. No</th>
			<th>User Name</th>
			<th>Email id</th>
			<th>Mobile Number</th>
			<th>Password</th>
			<th>Gender</th>
			<th>Profile picture</th>
			<th>Action</th>
		</thead>
			<?php $i=1;  if($login_check) { foreach($login_check as $row) { ?>
		<tbody>
			<td><?php echo $i++; ?></td>
			<td><?php echo $row['rg_username']; ?></td>
			<td><?php echo $row['rg_usermail']; ?></td>
			<td><?php echo $row['rg_user_phone']; ?></td>
			<td><?php echo $row['rg_user_pwd']; ?></td>
			<td><?php echo $row['rg_user_gender']; ?></td>
			<td><p><img src="<?php echo base_url(); ?><?php echo $row['rg_user_pic']; ?>" class="img-fluid rounded mr-3" height="100" width="100"></p></td>
			<!-- <td><a href="<?php echo site_url(); ?>" class="btn btn-primary"><i class="bi bi-pen"></i></a></td> -->
			<td><a href="<?php echo site_url('login/edit_user_profile/'. $row['user_id']); ?>"><button class="btn btn-lg" style="background-color:transparent;"><i class="bi bi-pen-fill"></i> Edit </button></a></td>
		</tbody>
			<?php }} ?>
	</table>
	<p><a href="<?php echo site_url('login/logout'); ?>">Logout</a></p>
</div>

</body>
</html>
