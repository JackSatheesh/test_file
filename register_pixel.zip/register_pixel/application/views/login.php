<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Login</title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<style type="text/css">
	.note
{
    text-align: center;
    height: 80px;
    background: -webkit-linear-gradient(left, #0072ff, #8811c5);
    color: #fff;
    font-weight: bold;
    line-height: 80px;
}
.form-content
{
    padding: 5%;
    border: 1px solid #ced4da;
    margin-bottom: 2%;
}
.form-control{
    border-radius:1.5rem;
}
.btnSubmit
{
    border:none;
    border-radius:1.5rem;
    padding: 1%;
    width: 20%;
    cursor: pointer;
    background: #0062cc;
    color: #fff;
}
</style>
<body>

<div class="container register-form">
	<?php if($this->session->flashdata('error')) flash_error(); if($this->session->flashdata('success')) flash_success(); ?>
    <div class="form">
        <div class="note">
            <p>Login Form </p>
        </div>
	  	<div class="form-content">
				<form method="POST" action="<?php echo site_url('login/submit_data');?>">
           <div class="col-md-6"> 
            <div class="row">
                <div class="col-md-12">
			    	<div class="form-group">
						<label>Email Id</label>
						<input type="text" name="user_email" class="form-control" placeholder="Enter Your Valid Email">
					</div>
				    <div class="form-group">
						<label>Password</label>
						<input type="password" name="user_pwd" class="form-control" placeholder="Enter Your Password">
					</div>
				</div>
				<button type="submit" class="btnSubmit">Submit</button>
            </div>
        </div>
		</form>
        </div>
    </div>
</div>

</body>
</html>
